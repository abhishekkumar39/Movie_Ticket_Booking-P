﻿using BookMyShow_DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShow_DAO
{
    public class Booking
    {
        public int Id { get; set; }
        public DateTime BookingDate { get; set; }
        public DateTime ShowTime { get; set; }
        public int MovieId { get; set; }
        public required Movie Movie { get; set; }
        public int UserId { get; set; }
        public required User User { get; set; }
        public int TheaterId { get; set; }
        public required Theater Theater { get; set; }

        public required Cancellation Cancellation { get; set; }
        public required Rescheduling Rescheduling { get; set; }
        public required ICollection<Payment> Payments { get; set; }
    }
}


