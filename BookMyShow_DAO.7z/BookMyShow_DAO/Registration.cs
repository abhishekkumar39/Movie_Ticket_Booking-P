﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShow_DAO
{
    public class Registration
    {
        public int Id { get; set; }
        public DateTime RegistrationDate { get; set; }
        public int UserId { get; set; }
        public required User User { get; set; }
    }
}

