﻿using Microsoft.EntityFrameworkCore;

namespace BookMyShow_DAO
{
    public class BookMyShowContext : DbContext
    {
        public BookMyShowContext(DbContextOptions<BookMyShowContext> options) : base(options) 
        { 
            this.Database.EnsureCreated();
        }

        public DbSet<Movie> Movies { get; set; }
        public DbSet<Theater> Theaters { get; set; }
        public DbSet<Registration> Registrations { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Cancellation> Cancellations { get; set; }
        public DbSet<Rescheduling> Reschedulings { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure Movie entity
            modelBuilder.Entity<Movie>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Description).HasMaxLength(1000);
                entity.Property(e => e.ReleaseDate).IsRequired();
                entity.Property(e => e.Genre).HasMaxLength(50);
                entity.Property(e => e.Rating).HasColumnType("decimal(3, 2)");
            });

            // Configure Theater entity
            modelBuilder.Entity<Theater>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Location).IsRequired().HasMaxLength(200);
            });

            // Configure Registration entity
            modelBuilder.Entity<Registration>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.RegistrationDate).IsRequired();
                entity.HasOne(e => e.User)
                      .WithMany(u => u.Registrations)
                      .HasForeignKey(e => e.UserId);
            });

            // Configure User entity
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Username).IsRequired().HasMaxLength(50);
                entity.Property(e => e.PasswordHash).IsRequired().HasMaxLength(256);
                entity.Property(e => e.Email).HasMaxLength(100);
            });

            // Configure Admin entity
            modelBuilder.Entity<Admin>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Username).IsRequired().HasMaxLength(50);
                entity.Property(e => e.PasswordHash).IsRequired().HasMaxLength(256);
                entity.Property(e => e.Email).HasMaxLength(100);
            });

            // Configure Booking entity
            modelBuilder.Entity<Booking>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.BookingDate).IsRequired();
                entity.Property(e => e.ShowTime).IsRequired();
                entity.HasOne(e => e.Movie)
                      .WithMany(m => m.Bookings)
                      .HasForeignKey(e => e.MovieId);
                entity.HasOne(e => e.User)
                      .WithMany(u => u.Bookings)
                      .HasForeignKey(e => e.UserId);
                entity.HasOne(e => e.Theater)
                      .WithMany(t => t.Bookings)
                      .HasForeignKey(e => e.TheaterId);
            });

            // Configure Cancellation entity
            modelBuilder.Entity<Cancellation>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.CancellationDate).IsRequired();
                entity.HasOne(e => e.Booking)
                      .WithOne(b => b.Cancellation)
                      .HasForeignKey<Cancellation>(e => e.BookingId);
            });

            // Configure Rescheduling entity
            modelBuilder.Entity<Rescheduling>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.RescheduleDate).IsRequired();
                entity.HasOne(e => e.Booking)
                      .WithOne(b => b.Rescheduling)
                      .HasForeignKey<Rescheduling>(e => e.BookingId);
            });

            // Configure Payment entity
            modelBuilder.Entity<Payment>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.PaymentDate).IsRequired();
                entity.Property(e => e.Amount).IsRequired().HasColumnType("decimal(18, 2)");
                entity.HasOne(e => e.Booking)
                      .WithMany(b => b.Payments)
                      .HasForeignKey(e => e.BookingId);
            });

            // Configure Feedback entity
            modelBuilder.Entity<Feedback>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Text).IsRequired().HasMaxLength(500);
                entity.Property(e => e.FeedbackDate).IsRequired();
                entity.HasOne(e => e.Movie)
                      .WithMany(m => m.Feedbacks)
                      .HasForeignKey(e => e.MovieId);
                entity.HasOne(e => e.User)
                      .WithMany(u => u.Feedbacks)
                      .HasForeignKey(e => e.UserId);
            });
        }
    }
}
